<?php
namespace Jtbc;
use App\Common\Ambassador;
use App\Common\Widgets\Breadcrumb\BreadcrumbBuilder;

class Diplomat extends Ambassador {
  private $breadcrumbBuilder;

  public function __start()
  {
    $this -> addParam('meta_title', Jtbc::take('index.title', 'lng'));
    $this -> breadcrumbBuilder = new BreadcrumbBuilder($this -> getParam('genre'));
    $this -> setParam('breadcrumb', $this -> breadcrumbBuilder -> build());
  }

  public function index()
  {
    return Jtbc::take('index.index');
  }
}